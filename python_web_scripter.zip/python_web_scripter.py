import os
import csv
import json
import time
import random
from typing import List, Dict
import logging

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException, WebDriverException

# Set up logging to track errors
logging.basicConfig(
    filename='scraping_errors.log',
    level=logging.ERROR,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

class AmazonBestSellersScraper:
    def __init__(self, email: str, password: str):
        self.email = email
        self.password = password
        chrome_options = webdriver.ChromeOptions()
        chrome_options.add_argument("--start-maximized")
        chrome_options.add_argument("--disable-extensions")
        chrome_options.add_argument("--disable-gpu")

        self.driver = webdriver.Chrome(options=chrome_options)
        self.wait = WebDriverWait(self.driver, 20)

    def login(self):
        """
        Login to Amazon using provided credentials, solving CAPTCHA only once.
        """
        try:
            self.driver.get("https://www.amazon.in/")
            
            sign_in_button = self.wait.until(
                EC.element_to_be_clickable((By.ID, "nav-link-accountList"))
            )
            sign_in_button.click()

            email_input = self.wait.until(
                EC.presence_of_element_located((By.ID, "ap_email"))
            )
            email_input.send_keys(self.email)

            continue_button = self.driver.find_element(By.ID, "continue")
            continue_button.click()

            password_input = self.wait.until(
                EC.presence_of_element_located((By.ID, "ap_password"))
            )
            password_input.send_keys(self.password)

            sign_in_submit = self.driver.find_element(By.ID, "signInSubmit")
            sign_in_submit.click()

            # Handle CAPTCHA only once
            if "captcha" in self.driver.current_url:
                print("CAPTCHA detected. Please solve it manually and press Enter to continue...")
                input()  # Wait for user input to continue after solving CAPTCHA
                save_cookies(self.driver)  # Save cookies after solving CAPTCHA to avoid re-solving

            time.sleep(5)

        except Exception as e:
            logging.error(f"Login failed: {e}")
            print(f"Login failed: {e}")
            raise

    def scrape_category(self, category_url: str, max_products: int = 1500) -> List[Dict]:
        try:
            self.driver.get(category_url)
            category_name = self.driver.title.split(" : ")[0]

            products = []
            processed_products = set()

            while len(products) < max_products:
                product_elements = self.wait.until(
                    EC.presence_of_all_elements_located(
                        (By.CSS_SELECTOR, ".zg-item-immersion")
                    )
                )

                for product in product_elements:
                    if len(products) >= max_products:
                        break

                    try:
                        product_name = product.find_element(By.CSS_SELECTOR, ".p13n-sc-truncate").text.strip()

                        if product_name in processed_products:
                            continue

                        price = "N/A"
                        try:
                            price_element = product.find_element(By.CSS_SELECTOR, ".p13n-sc-price")
                            price = price_element.text.strip()
                        except NoSuchElementException:
                            pass

                        discount = "N/A"
                        discount_percentage = 0
                        try:
                            discount_element = product.find_element(By.CSS_SELECTOR, ".a-size-small.a-color-price")
                            discount = discount_element.text.strip()

                            discount_percentage = int(discount.split('%')[0])

                            if discount_percentage <= 50:
                                continue
                        except (NoSuchElementException, ValueError):
                            pass

                        rating = "N/A"
                        try:
                            rating_element = product.find_element(By.CSS_SELECTOR, ".a-icon-alt")
                            rating = rating_element.text.strip()
                        except NoSuchElementException:
                            pass

                        product_details = {
                            "Category": category_name,
                            "Product Name": product_name,
                            "Price": price,
                            "Discount": discount,
                            "Rating": rating
                        }

                        products.append(product_details)
                        processed_products.add(product_name)

                    except Exception as e:
                        logging.error(f"Error processing product: {e}")

                try:
                    next_button = self.driver.find_element(By.CSS_SELECTOR, ".a-last a")
                    next_button.click()
                    time.sleep(random.uniform(2, 4))  # Random delay
                except Exception:
                    break  # No more pages

            return products

        except Exception as e:
            logging.error(f"Error scraping category {category_url}: {e}")
            print(f"Error scraping category {category_url}: {e}")
            return []

    def save_data(self, data: List[Dict], output_format: str = 'csv'):
        os.makedirs('output', exist_ok=True)
        timestamp = time.strftime("%Y%m%d-%H%M%S")

        if output_format == 'csv':
            filename = f'output/amazon_bestsellers_{timestamp}.csv'
            keys = data[0].keys()
            with open(filename, 'w', newline='', encoding='utf-8') as f:
                dict_writer = csv.DictWriter(f, keys)
                dict_writer.writeheader()
                dict_writer.writerows(data)

        elif output_format == 'json':
            filename = f'output/amazon_bestsellers_{timestamp}.json'
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4)

        print(f"Data saved to {filename}")

    def run_scraping(self, categories: List[str]):
        try:
            self.login()

            all_products = []
            for category_url in categories:
                print(f"Scraping category: {category_url}")
                category_products = self.scrape_category(category_url)
                all_products.extend(category_products)
                time.sleep(random.uniform(2, 5))  # Delay between categories

            self.save_data(all_products)

        except Exception as e:
            logging.error(f"Scraping failed: {e}")
            print(f"Scraping failed: {e}")

        finally:
            self.driver.quit()


def save_cookies(driver):
    """
    Save cookies after solving CAPTCHA to avoid solving it in future runs
    """
    with open("cookies.pkl", "wb") as file:
        pickle.dump(driver.get_cookies(), file)
    print("Cookies saved after solving CAPTCHA.")

def load_cookies(driver):
    """
    Load cookies to bypass login and CAPTCHA in future runs
    """
    if os.path.exists("cookies.pkl"):
        with open("cookies.pkl", "rb") as file:
            cookies = pickle.load(file)
            for cookie in cookies:
                driver.add_cookie(cookie)
        print("Cookies loaded. Skipping login.")
    else:
        print("Cookies file not found. Logging in...")

def main():
    EMAIL = "your_email@example.com"
    PASSWORD = "your_password"

    CATEGORIES = [
        "https://www.amazon.in/gp/bestsellers/kitchen/ref=zg_bs_nav_kitchen_0",
        "https://www.amazon.in/gp/bestsellers/shoes/ref=zg_bs_nav_shoes_0",
        "https://www.amazon.in/gp/bestsellers/computers/ref=zg_bs_nav_computers_0",
        "https://www.amazon.in/gp/bestsellers/electronics/ref=zg_bs_nav_electronics_0"
    ]

    scraper = AmazonBestSellersScraper(EMAIL, PASSWORD)
    scraper.run_scraping(CATEGORIES)


if __name__ == "__main__":
    main()
